#include "SpaceCraftFactory.h"

SpaceCraftFactory::SpaceCraftFactory() {

};

SpaceCraftFactory::~SpaceCraftFactory() {

};