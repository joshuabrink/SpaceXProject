#ifndef STATE_H
#define STATE_H

class State {

};

#endif
