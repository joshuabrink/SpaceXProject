#ifndef TRANSPORTENTITY_H
#define TRANSPORTENTITY_H
class TransportEntity
{
private:
    /* data */
public:
    TransportEntity(/* args */) {}
    ~TransportEntity() {}
};
#endif