#ifndef TRANSPORTENTITYCREW_H
#define TRANSPORTENTITYCREW_H
#include "TransportEntity.h"
class TransportEntityCrew : public TransportEntity
{
private:
    
public:
    TransportEntityCrew(/* args */) {}
    ~TransportEntityCrew() {}
};
#endif