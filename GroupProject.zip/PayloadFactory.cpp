#include "PayloadFactory.h"

PayloadFactory::PayloadFactory() {

}

PayloadFactory::~PayloadFactory() {

}